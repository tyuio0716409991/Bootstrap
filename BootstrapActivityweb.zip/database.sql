CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50),
  email VARCHAR(50),
  age INT
);


INSERT INTO users (name, email, age) VALUES ('John Doe', 'john@example.com', 25);


UPDATE users SET name = 'Jane Smith', age = 30 WHERE id = 1;

DELETE FROM users WHERE id = 1;
