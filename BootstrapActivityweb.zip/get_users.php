<?php
// الاتصال بقاعدة البيانات
$servername = "127.0.0.1";
            $username = "root";
            $password ="root";
            $dbname = "bootstrap";
$conn = new mysqli($servername, $username, $password, $dbname);

// التحقق من وجود اتصال صحيح
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// جلب بيانات المستخدمين من قاعدة البيانات
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

// إعداد جدول لعرض بيانات المستخدمين
$table = '<table class="table table-striped">
            <thead>
                <tr>
                    <th>الاسم</th>
                    <th>البريد الإلكتروني</th>
                    <th>العمر</th>
                </tr>
            </thead>
            <tbody>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $name = $row["name"];
        $email = $row["email"];
        $age = $row["age"];
        
        // إضافة سطر جديد للجدول
        $table .= '<tr>
                    <td>'.$name.'</td>
                    <td>'.$email.'</td>
                    <td>'.$age.'</td>
                </tr>';
    }
} else {
    // رسالة لعدم وجود مستخدمين
    $table .= '<tr><td colspan="3">لا يوجد مستخدمين</td></tr>';
}

$table .= '</tbody></table>';

// إغلاق الاتصال بقاعدة البيانات
$conn->close();

// إرجاع الجدول كنص HTML
echo $table;
?>
