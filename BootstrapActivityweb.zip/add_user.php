<?php
// الاتصال بقاعدة البيانات
$servername = "127.0.0.1";
            $username = "root";
            $password ="root";
            $dbname = "bootstrap";
            $conn = new mysqli($servername, $username, $password, $dbname);

// التحقق من وجود اتصال صحيح
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}else{

// جمع البيانات المرسلة من النموذج
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];

// إضافة المستخدم إلى قاعدة البيانات
$sql = "INSERT INTO users (name, email, age) VALUES ('$name', '$email', '$age')";
if ($conn->query($sql) === TRUE) {
    echo "تم إضافة المستخدم بنجاح";
} else {
    echo "حدث خطأ أثناء إضافة المستخدم: " . $conn->error;
}
}
// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
