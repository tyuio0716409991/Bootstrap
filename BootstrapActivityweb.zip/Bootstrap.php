<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>صفحة المستخدمين</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h1>جدول المستخدمين</h1>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>الاسم</th>
                <th>البريد الإلكتروني</th>
                <th>العمر</th>
            </tr>
        </thead>
        <tbody id="usersTableBody">
            <?php
            // الاتصال بقاعدة البيانات
            $servername = "127.0.0.1";
            $username = "root";
            $password ="root";
            $dbname = "bootstrap";
            $conn = new mysqli($servername, $username, $password, $dbname);

            // التحقق من وجود اتصال صحيح
            if ($conn->connect_error) {
                die("فشل الاتصال: " . $conn->connect_error);
            }

            // استعلام لجلب البيانات من قاعدة البيانات
            $sql = "SELECT * FROM users";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row["name"]."</td>";
                    echo "<td>".$row["email"]."</td>";
                    echo "<td>".$row["age"]."</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>لا يوجد مستخدمين</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>

    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addUserModal">
        إضافة مستخدم جديد
    </button>
</div>

<!-- Modal لإضافة مستخدم جديد -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
                       <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">إنشاء مستخدم جديد</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="addUserForm" method="POST" action="add_user.php">
                    <div class="form-group">
                        <label for="name">الاسم:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">البريد الإلكتروني:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="age">العمر:</label>
                        <input type="number" class="form-control" id="age" name="age" required>
                    </div>
                    <button type="submit" class="btn btn-primary">إضافة</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- استدعاء مكتبة jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<!-- استدعاء مكتبة Bootstrap -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <script>
        // استدعاء دالة لجلب بيانات المستخدمين عند تحميل الصفحة
        $(document).ready(function() {
            getUsers();
        });

        // استدعاء دالة عند تقديم النموذج
        $(document).ready(function() {
            $("#addUserForm").submit(function(event) {
                event.preventDefault(); // منع إعادة تحميل الصفحة عند تقديم النموذج

                // جمع البيانات المدخلة من النموذج
                var name = $("#name").val();
                var email = $("#email").val();
                var age = $("#age").val();

                // إرسال البيانات باستخدام AJAX
                $.ajax({
                    type: "POST",
                    url: "add_user.php",
                    data: { name: name, email: email, age: age },
                    success: function(data) {
                        // عرض رسالة النجاح أو الخطأ
                        alert(data);

                        // إعادة تحميل الجدول لتحديثه
                        getUsers();

                        // إغلاق النموذج
                        $("#addUserModal").modal("hide");
                    }
                });
            });
        });

        // استدعاء دالة لجلب بيانات المستخدمين
        function getUsers() {
            $.ajax({
                type: "GET",
                url: "get_users.php",
                success: function(data) {
                    $("#usersTableBody").html(data);
                }
            });
        }
    </script>

</body>
</html>
